package com.example.ibuy2;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;

import com.example.ibuy2.databinding.ActivityItemsBinding;

import java.util.ArrayList;

public class ItemsActivity extends ListActivity {

    private ActivityItemsBinding binding;
    private ArrayList<String> listItems = new ArrayList<String>();
    private ArrayAdapter<String> adapter;
    private EditText barcode;

    int clickCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityItemsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //setSupportActionBar(binding.toolbar);

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listItems);
        setListAdapter(adapter);
    }

    public void addItems(View v) {
        barcode = (EditText) findViewById(R.id.barcode);
        listItems.add(barcode.getText().toString());
        barcode.getText().clear();
        adapter.notifyDataSetChanged();
    }
}